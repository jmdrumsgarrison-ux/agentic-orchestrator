---
title: AgentiveOrchestrator
emoji: 🚀
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: "4.44.1"
app_file: app.py
pinned: false
---

# AgentiveOrchestrator

AO v0.8.4 — GPT-5 + uploads + banner + rich text.
