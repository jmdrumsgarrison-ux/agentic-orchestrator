# HF Orchestrator — Drop70 (Top-Level Files)

**Contents (all in Space root):**
- app.py
- orchestrator.py
- defaults.json
- requirements.txt

**Usage (on Hugging Face):**
1. Open your Space (SDK: Gradio).
2. Upload all files from this zip directly into the **Space root** (no subfolders).
3. Spaces will install `requirements.txt` and run `app.py` automatically.
