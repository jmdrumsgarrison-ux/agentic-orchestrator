---
title: AgentiveOrchestrator
emoji: 🧩
colorFrom: indigo
colorTo: blue
sdk: gradio
sdk_version: "4.44.1"
app_file: app.py
pinned: false
---

# AO v0.8.8

- Rich editor (HTML → Markdown) with a single **Send** button that posts straight into the chat.
- No markup panel shown.
- File uploads supported.
- Version banner shows `OPENAI_MODEL`.
