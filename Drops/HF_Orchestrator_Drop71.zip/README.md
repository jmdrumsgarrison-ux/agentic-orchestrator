---
title: HF Orchestrator — Drop71
emoji: 🚀
colorFrom: blue
colorTo: green
sdk: gradio
sdk_version: "4.31.0"
app_file: app.py
pinned: false
---

# HF Orchestrator — Drop71

This drop includes:
- `app.py` — Gradio entrypoint
- `orchestrator.py` — auto-repair for missing GitPython
- `defaults.json` — GUI defaults (Namespace, Space name, Repo URL)
- `requirements.txt`

Everything is at the Space root. Hugging Face will read the metadata above automatically.
