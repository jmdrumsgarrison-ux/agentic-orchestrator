---
title: AgentiveOrchestrator
emoji: 🚀
colorFrom: indigo
colorTo: blue
sdk: gradio
sdk_version: 4.37.2
app_file: app.py
pinned: false
---

AO — baseline chat + Markdown editor + uploads. Set `OPENAI_API_KEY` and `OPENAI_MODEL` for real LLM calls.
